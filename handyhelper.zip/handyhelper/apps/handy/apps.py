from django.apps import AppConfig


class HandyConfig(AppConfig):
    name = 'handy'
